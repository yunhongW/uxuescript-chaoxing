<script setup lang="ts">
import FolderCodeIcon from "@/assets/folder-code.svg?component";
import { useScaleFeedback } from "@/composables/useScaleFeedback";
import { commands } from "@/services/cmds";
import { openPath } from "@tauri-apps/plugin-opener";
import { label } from "@/labels";
import VRollTransition from "@/components/base/VRollTransition.vue";

defineProps<{
  version: string;
  author: string;
}>();

const scaleFeedback = useScaleFeedback({ hoverScale: 1.1 });

const openDataDirectory = async () => {
  const paths = await commands.paths();
  const dataDirectory = paths.dirs?.data;

  if (dataDirectory) {
    await openPath(dataDirectory);
  }
};
</script>

<template>
  <footer class="bottom-bar">
    <button
      type="button"
      class="directory-entry"
      :aria-label="label('dataDirectory')"
      @click="openDataDirectory"
      @pointerenter="scaleFeedback.handlePointerEnter"
      @pointerleave="scaleFeedback.handlePointerLeave"
      @pointerdown="scaleFeedback.handlePointerDown"
      @pointerup="scaleFeedback.handlePointerUp"
    >
      <FolderCodeIcon class="directory-icon" />
      <VRollTransition :value="label('dataDirectory')" class="directory-text" aria-hidden="true" v-slot="{ value }">
        {{ value }}
      </VRollTransition>
    </button>
    <div class="version-info">
      <p>by {{ author }} v{{ version }}</p>
    </div>
  </footer>
</template>

<style scoped>
.directory-text {
  width: 20ch;
  height: 1.5em;
}

.bottom-bar {
  background-color: transparent;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.directory-entry {
  appearance: none;
  border: 0;
  background: transparent;
  padding-left: 2.5vw;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  color: var(--theme-brand);
  cursor: pointer;
  font-size: 1.25rem;
  font-family: inherit;
  line-height: inherit;
  text-align: left;
  transform-origin: center;
}

.directory-icon {
  width: 1.5rem;
  height: 1.5rem;
}

.version-info {
  padding-right: 2.5vw;
  display: flex;
  align-items: center;
  justify-content: flex-end;
}
</style>
