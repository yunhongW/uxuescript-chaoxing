/// <reference types="vite/client" />
/// <reference types="vite-svg-loader" />

interface Window {
  previewUpdateDownload?: () => Promise<void>;
}

declare module "*.vue" {
  import type { DefineComponent } from "vue";
  const component: DefineComponent<
    Record<string, never>,
    Record<string, never>,
    unknown
  >;
  export default component;
}
