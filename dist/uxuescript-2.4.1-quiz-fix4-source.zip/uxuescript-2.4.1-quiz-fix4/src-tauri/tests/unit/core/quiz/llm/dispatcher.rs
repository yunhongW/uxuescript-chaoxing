use super::*;
use crate::config::llm::ApiKey;
use crate::test_support::http::{response, serve};
use serde_json::json;

#[tokio::test]
async fn health_check_accepts_a_plain_text_short_answer_for_each_protocol() {
    let text = "因为太阳光进入大气层后，波长较短的蓝光被空气分子散射得比波长较长的光更强烈，所以天空呈蓝色";
    for protocol in [
        LLMProtocol::OpenAIChatCompletions,
        LLMProtocol::OpenAIResponses,
        LLMProtocol::GoogleGemini,
    ] {
        let body = match protocol {
            LLMProtocol::OpenAIChatCompletions => {
                json!({"choices": [{"message": {"content": text}}]})
            }
            LLMProtocol::OpenAIResponses => {
                json!({"output": [{"type": "message", "content": [{"text": text}]}]})
            }
            LLMProtocol::GoogleGemini => {
                json!({"candidates": [{"content": {"parts": [{"text": text}]}}]})
            }
        };
        let (url, request) = serve(200, body.to_string()).await;
        let provider = LLMProvider {
            name: "Local mock".into(),
            is_custom: true,
            protocol,
            base_url: url,
            api_key: None,
            models: vec!["mock-model".into()],
            chosen_model: Some(0),
            extra_body: None,
        };
        let answers = solve(
            &provider,
            vec![Question {
                id: "1".into(),
                kind: "简答题".into(),
                stem: "天空为什么是蓝色的？请用一句话回答。".into(),
                options: Vec::new(),
            }],
        )
        .await
        .unwrap();
        request.await.unwrap();
        assert_eq!(answers.len(), 1);
        assert_eq!(answers[0].index, "1");
        assert_eq!(answers[0].content, text);
        assert!(answers[0].explanation.is_empty());
    }
}

#[tokio::test]
async fn accepts_numbered_judgment_answers_for_each_protocol() {
    let text = "答案：\n36. A 对\n37. B 错\n38. B 错\n39. B 错\n40. B 错\n\n简要说明：\n- 37：题干定义颠倒。";
    for protocol in [
        LLMProtocol::OpenAIChatCompletions,
        LLMProtocol::OpenAIResponses,
        LLMProtocol::GoogleGemini,
    ] {
        let body = match protocol {
            LLMProtocol::OpenAIChatCompletions => {
                json!({"choices": [{"message": {"content": text}}]})
            }
            LLMProtocol::OpenAIResponses => {
                json!({"output": [{"type": "message", "content": [{"text": text}]}]})
            }
            LLMProtocol::GoogleGemini => {
                json!({"candidates": [{"content": {"parts": [{"text": text}]}}]})
            }
        };
        let (url, request) = serve(200, body.to_string()).await;
        let provider = LLMProvider {
            name: "Local mock".into(),
            is_custom: true,
            protocol,
            base_url: url,
            api_key: None,
            models: vec!["mock-model".into()],
            chosen_model: Some(0),
            extra_body: None,
        };
        let questions = (36..=40)
            .map(|id| Question {
                id: id.to_string(),
                kind: "【判断题】".into(),
                stem: "判断以下表述。".into(),
                options: vec!["A 对".into(), "B 错".into()],
            })
            .collect();
        let answers = solve(&provider, questions).await.unwrap();
        request.await.unwrap();
        assert_eq!(answers.len(), 5);
        assert_eq!(answers[0].index, "36");
        assert_eq!(answers[0].content, "A");
        assert_eq!(answers[4].index, "40");
        assert_eq!(answers[4].content, "B");
    }
}

#[tokio::test]
async fn preset_chat_requests_preserve_options_and_read_answer_arrays() {
    for (id, path, model, thinking) in [
        (
            "bailian",
            "/compatible-mode/v1/chat/completions",
            "qwen3.8-flash",
            Some(false),
        ),
        (
            "siliconflow",
            "/v1/chat/completions",
            "deepseek-ai/DeepSeek-V4.1-Flash",
            None,
        ),
    ] {
        let mut provider = crate::config::llm::LLMConfig::default()
            .providers
            .into_inner()
            .remove(id)
            .unwrap();
        let body = response(
            &provider.protocol,
            json!([{"index":"1","explanation":"mock","content":"A"}]),
        );
        let (url, request) = serve(200, body).await;
        let preset_path = tauri::Url::parse(&provider.base_url)
            .unwrap()
            .path()
            .to_owned();
        provider.base_url = format!("{url}{preset_path}");
        provider.api_key = Some(ApiKey::new("mock-api-key".into()).unwrap());

        let answers = solve(
            &provider,
            vec![Question {
                id: "1".into(),
                kind: "single".into(),
                stem: "Choose A".into(),
                options: vec!["A".into()],
            }],
        )
        .await
        .unwrap();
        let request = request.await.unwrap();
        assert!(request.head.starts_with(&format!("POST {path} ")));
        assert_eq!(request.headers["authorization"], "Bearer mock-api-key");
        assert_eq!(request.body["model"], model);
        assert_eq!(
            request
                .body
                .get("enable_thinking")
                .and_then(serde_json::Value::as_bool),
            thinking
        );
        assert_eq!(request.body["stream"], false);
        assert!(request.body.get("extra_body").is_none());
        assert_eq!(answers.len(), 1);
        assert_eq!(answers[0].content, "A");
    }
}

#[tokio::test]
async fn sends_protocol_requests_with_application_headers() {
    for protocol in [
        LLMProtocol::OpenAIChatCompletions,
        LLMProtocol::OpenAIResponses,
        LLMProtocol::GoogleGemini,
    ] {
        let body = response(
            &protocol,
            json!([{"index":"1","explanation":"mock","content":"A"}]),
        );
        let (url, request) = serve(200, body).await;
        let path = match protocol {
            LLMProtocol::OpenAIChatCompletions => "/v1/chat/completions",
            LLMProtocol::OpenAIResponses => "/v1/responses",
            LLMProtocol::GoogleGemini => "/models",
        };
        let provider = LLMProvider {
            name: "Local mock".into(),
            is_custom: true,
            protocol,
            base_url: format!("{url}{path}"),
            api_key: Some(ApiKey::new("mock-api-key".into()).unwrap()),
            models: vec!["mock-model".into()],
            chosen_model: Some(0),
            extra_body: None,
        };
        let answers = solve(
            &provider,
            vec![Question {
                id: "1".into(),
                kind: "???".into(),
                stem: "?? A".into(),
                options: vec!["A".into()],
            }],
        )
        .await
        .unwrap();
        let request = request.await.unwrap();
        let head = request.head;
        let headers = request.headers;
        let body = request.body;
        assert_eq!(
            headers["user-agent"],
            concat!("uXueScript/", env!("CARGO_PKG_VERSION"))
        );
        assert_eq!(headers["accept"], "application/json");
        assert_eq!(headers["content-type"], "application/json");
        assert!(!headers.contains_key("accept-language"));
        match provider.protocol {
            LLMProtocol::OpenAIChatCompletions => {
                assert!(head.starts_with("POST /v1/chat/completions "));
                assert_eq!(headers["authorization"], "Bearer mock-api-key");
                assert_eq!(body["model"], "mock-model");
                assert!(body["messages"].is_array());
                assert_eq!(body["messages"][0]["content"], SYSTEM_PROMPT);
            }
            LLMProtocol::OpenAIResponses => {
                assert!(head.starts_with("POST /v1/responses "));
                assert_eq!(headers["authorization"], "Bearer mock-api-key");
                assert_eq!(body["model"], "mock-model");
                assert!(body["input"].is_string());
                assert_eq!(body["instructions"], SYSTEM_PROMPT);
            }
            LLMProtocol::GoogleGemini => {
                assert!(head.starts_with("POST /models/mock-model:generateContent "));
                assert_eq!(headers["x-goog-api-key"], "mock-api-key");
                assert!(body["contents"].is_array());
                assert_eq!(body["systemInstruction"]["parts"][0]["text"], SYSTEM_PROMPT);
            }
        }
        assert_eq!(answers.len(), 1);
        assert_eq!(answers[0].index, "1");
        assert_eq!(answers[0].content, "A");
    }
}
