use super::*;

#[test]
fn test_classify_urls() {
    let url = "https://i.chaoxing.com".parse().unwrap();
    assert_eq!(classify(&url), Type::MainSpace);

    let url = "https://mooc1.chaoxing.com/mycourse/...".parse().unwrap();
    assert_eq!(classify(&url), Type::Course);

    let url = "https://mooc1.chaoxing.com/visit/stucoursemiddle?courseid=1"
        .parse()
        .unwrap();
    assert_eq!(classify(&url), Type::Other);

    let url = "https://passport2.chaoxing.com/login?refer=https://www.chaoxing.com"
        .parse()
        .unwrap();
    assert_eq!(classify(&url), Type::Login);

    let url = "https://example.com".parse().unwrap();
    assert_eq!(classify(&url), Type::Unknown);

    let url = "https://mooc2-ans.chaoxing.com".parse().unwrap();
    assert_eq!(classify(&url), Type::CourseOverview);
}

#[test]
fn recognizes_legacy_and_sharded_learning_pages() {
    for host in ["mooc1", "mooc1-1", "mooc1-2", "mooc1-12"] {
        for path in ["/mycourse/", "/mooc-ans/mycourse/"] {
            let url =
                format!("https://{host}.chaoxing.com{path}studentstudy?courseId=1&chapterId=2")
                    .parse()
                    .unwrap();
            assert_eq!(classify(&url), Type::Course, "{url}");
        }
    }
}

#[test]
fn keeps_unrelated_hosts_and_pages_out_of_course_scripts() {
    for (address, expected) in [
        (
            "https://mooc1-abc.chaoxing.com/mycourse/studentstudy",
            Type::Other,
        ),
        (
            "https://mooc1-.chaoxing.com/mycourse/studentstudy",
            Type::Other,
        ),
        (
            "https://mooc10.chaoxing.com/mycourse/studentstudy",
            Type::Other,
        ),
        (
            "https://mooc1-2.extra.chaoxing.com/mycourse/studentstudy",
            Type::Other,
        ),
        (
            "https://mooc1-2.chaoxing.com/visit/stucoursemiddle?courseid=1",
            Type::Other,
        ),
        (
            "https://mooc1-2.chaoxing.com/mooc-ans/mycourse",
            Type::Other,
        ),
        (
            "https://mooc1-2.chaoxing.com/mooc-ans/mycourse-other/studentstudy",
            Type::Other,
        ),
        (
            "https://mooc1-2.chaoxing.com/ananas/modules/video/index.html",
            Type::Other,
        ),
        (
            "https://mooc2-ans.chaoxing.com/mooc-ans/mycourse/studentstudy",
            Type::CourseOverview,
        ),
        (
            "https://mooc1-2.example.com/mooc-ans/mycourse/studentstudy",
            Type::Unknown,
        ),
        (
            "https://mooc1-2.chaoxing.com.example.com/mycourse/studentstudy",
            Type::Unknown,
        ),
    ] {
        let url = address.parse().unwrap();
        assert_eq!(classify(&url), expected, "{url}");
    }
}

#[test]
fn selects_the_course_script_for_the_reported_learning_page() {
    let url = "https://mooc1-2.chaoxing.com/mooc-ans/mycourse/studentstudy?courseId=1"
        .parse()
        .unwrap();
    assert!(
        crate::core::script::obtain(classify(&url)).is_some(),
        "The reported learning page must receive the course script."
    );
}
