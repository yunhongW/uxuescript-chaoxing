/// 提供基于 URL 结构与域名分类判定及脚本匹配功能的核心模块。
/// 基于结构与域名特征进行归类的 URL 类型枚举。
#[derive(Debug, PartialEq, Eq, Clone, Copy)]
pub enum Type {
    Course,
    CourseOverview,
    Login,
    MainSpace,
    Other,
    Unknown,
}

/// 判定传入 URL 是否属于超星域名并返回其具体分类类型。
pub fn classify(url: &tauri::Url) -> Type {
    let host = url.host_str().unwrap_or_default();

    if host != "chaoxing.com" && !host.ends_with(".chaoxing.com") {
        return Type::Unknown;
    }

    // 学习页也会使用 mooc1-2 等分片域名及 /mooc-ans 路径前缀。
    let course_sub = host.strip_suffix(".chaoxing.com").unwrap_or_default();
    let is_course_host = course_sub == "mooc1"
        || course_sub.strip_prefix("mooc1-").is_some_and(|suffix| {
            !suffix.is_empty() && suffix.bytes().all(|byte| byte.is_ascii_digit())
        });
    let sub = host.split('.').next().unwrap_or_default();
    match sub {
        "i" => Type::MainSpace,
        _ if is_course_host
            && (url.path().starts_with("/mycourse/")
                || url.path().starts_with("/mooc-ans/mycourse/")) =>
        {
            Type::Course
        }
        "mooc2-ans" => Type::CourseOverview,
        "passport2" if url.path().starts_with("/login") => Type::Login,
        _ => Type::Other,
    }
}

#[cfg(test)]
#[path = "../../tests/unit/core/url.rs"]
mod tests;
