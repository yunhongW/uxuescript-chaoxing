use super::super::html::Question;
use super::AnswerItem;

use anyhow::{Context, Result, bail, ensure};
use serde_json::Value;
use std::collections::HashSet;

pub(super) fn parse_answers(content: &str, questions: &[Question]) -> Result<Vec<AnswerItem>> {
    let text = content.trim();
    ensure!(!text.is_empty(), "AI 未返回答案文本");

    let fenced = text.starts_with("```");
    let json = if fenced {
        let (header, body) = text
            .split_once('\n')
            .context("答案 Markdown 代码块不完整")?;
        ensure!(
            header.trim() == "```" || header.trim().eq_ignore_ascii_case("```json"),
            "答案 Markdown 代码块必须使用 JSON 格式"
        );
        body.trim_end()
            .strip_suffix("```")
            .context("答案 Markdown 代码块不完整")?
            .trim()
    } else {
        text
    };

    let parsed = match serde_json::from_str::<Value>(json) {
        Ok(value) => Ok(value),
        Err(error) => match repair_unterminated_strings(json) {
            Some(repaired) => serde_json::from_str::<Value>(&repaired),
            None => Err(error),
        },
    };

    let answers = match parsed {
        Ok(Value::Array(items)) => serde_json::from_value(Value::Array(items))
            .context("答案 JSON 数组字段格式不符合要求")?,
        Ok(Value::Object(mut object)) => {
            if let Some(answers) = object.remove("answers") {
                ensure!(answers.is_array(), "答案 JSON 中的 answers 必须是数组");
                serde_json::from_value(answers).context("answers 数组字段格式不符合要求")?
            } else {
                vec![
                    serde_json::from_value(Value::Object(object))
                        .context("单个答案 JSON 对象字段格式不符合要求")?,
                ]
            }
        }
        Ok(_) => bail!("答案 JSON 必须是数组、answers 数组包装或单个答案对象"),
        Err(error) => {
            // Gateways may ignore JSON instructions; malformed JSON stays on the error path.
            if fenced || has_json_syntax(text) {
                bail!("答案 JSON 解析失败: {error}");
            }
            if questions.len() == 1
                && matches!(questions[0].kind.trim(), "简答题" | "【简答题】")
                && questions[0].options.is_empty()
            {
                ensure!(!looks_like_json(text), "答案 JSON 解析失败: {error}");
                vec![AnswerItem {
                    index: questions[0].id.clone(),
                    explanation: String::new(),
                    content: content.to_owned(),
                }]
            } else {
                parse_numbered_choices(text, questions)?
            }
        }
    };

    validate_answers(answers, questions)
}

/// 模型偶尔用中文引号收尾，导致该行英文引号为奇数、JSON 字符串不闭合。
/// 对这类行在行尾补一个英文引号；只有补齐后整段仍能解析成 JSON 时才会采用。
fn repair_unterminated_strings(text: &str) -> Option<String> {
    let mut repaired = String::with_capacity(text.len() + 8);
    let mut changed = false;
    for line in text.lines() {
        let mut quotes = 0usize;
        let mut escaped = false;
        for character in line.chars() {
            if escaped {
                escaped = false;
                continue;
            }
            match character {
                '\\' => escaped = true,
                '"' => quotes += 1,
                _ => {}
            }
        }
        repaired.push_str(line);
        if quotes % 2 == 1 && line.contains(':') {
            repaired.push('"');
            changed = true;
        }
        repaired.push('\n');
    }
    changed.then_some(repaired)
}

fn has_json_syntax(text: &str) -> bool {
    text.contains(['{', '}', '[', ']']) || text.starts_with('"') || text.contains("```")
}

fn looks_like_json(text: &str) -> bool {
    has_json_syntax(text)
        || text.split_once(':').is_some_and(|(key, _)| {
            matches!(
                key.trim().trim_matches('"'),
                "index"
                    | "id"
                    | "explanation"
                    | "content"
                    | "answer"
                    | "answers"
                    | "题号"
                    | "解析"
                    | "答案"
            )
        })
}

fn section_body<'a>(line: &'a str, headings: &[&str]) -> Option<&'a str> {
    // 模型常把段落标题写成 "**答案：**"、"## 答案：" 或 "- 简要说明："，先去掉行首修饰。
    let text = line.trim_start_matches(|character: char| {
        character.is_whitespace() || matches!(character, '#' | '>' | '*' | '-')
    });
    headings.iter().find_map(|heading| {
        text.strip_prefix(*heading)
            .and_then(|body| body.strip_prefix('：').or_else(|| body.strip_prefix(':')))
            .map(|body| body.trim().trim_matches('*').trim())
    })
}

/// 从一行中提取全部“题号 + 答案”片段。
/// 兼容全角句点、顿号、右括号等编号分隔符，以及同一行内用空格分隔的多个答案。
fn numbered_segments(line: &str) -> Vec<(&str, &str)> {
    let Ok(separator) = regex::Regex::new(r"(\d+)\s*[.．、)）:：]\s*") else {
        return Vec::new();
    };
    let mut marks = Vec::new();
    for captures in separator.captures_iter(line) {
        let whole = captures.get(0).expect("whole match");
        let digits = captures.get(1).expect("digits");
        // 题号必须位于行首或分隔符之后，避免把版本号等文本当成题号。
        let boundary = line[..whole.start()]
            .chars()
            .next_back()
            .is_none_or(|character| {
                character.is_whitespace() || matches!(character, '；' | ';' | '，' | ',' | '、')
            });
        if boundary {
            marks.push((digits.as_str(), whole.start(), whole.end()));
        }
    }
    marks
        .iter()
        .enumerate()
        .map(|(index, (id, _, end))| {
            let tail = marks
                .get(index + 1)
                .map_or(line.len(), |(_, next, _)| *next);
            let value = line[*end..tail].trim_end_matches(|character: char| {
                character.is_whitespace() || matches!(character, '；' | ';' | '，' | ',' | '。')
            });
            (*id, value)
        })
        .collect()
}

fn table_cells(line: &str) -> Option<(&str, &str)> {
    let mut cells = line.strip_prefix('|')?.strip_suffix('|')?.split('|');
    let first = cells.next()?.trim();
    let second = cells.next()?.trim();
    cells.next().is_none().then_some((first, second))
}

fn finish_choice_block(
    current: &mut Vec<AnswerItem>,
    canonical: &mut Option<Vec<AnswerItem>>,
    questions: &[Question],
) -> Result<()> {
    if current.is_empty() {
        return Ok(());
    }
    let answers = validate_answers(std::mem::take(current), questions)?;
    if let Some(previous) = canonical {
        ensure!(
            answers.iter().all(|answer| previous
                .iter()
                .any(|item| { item.index == answer.index && item.content == answer.content })),
            "多个答案区块的内容不一致"
        );
    } else {
        *canonical = Some(answers);
    }
    Ok(())
}

fn numbered_choice(
    id: &str,
    value: &str,
    questions: &[Question],
    pattern: &regex::Regex,
) -> Result<AnswerItem> {
    let id = id.trim();
    ensure!(
        !id.is_empty() && id.bytes().all(|byte| byte.is_ascii_digit()),
        "编号答案必须使用原题号"
    );
    let question = questions
        .iter()
        .find(|question| question.id == id)
        .with_context(|| format!("答案题号不匹配: {id}"))?;
    let (value, notes) = value
        .split_once("——")
        .map_or((value, ""), |(answer, notes)| (answer, notes.trim()));
    let value = value.trim();
    let value = if value.starts_with("**") || value.ends_with("**") {
        value
            .strip_prefix("**")
            .and_then(|body| body.strip_suffix("**"))
            .context("编号答案的 Markdown 加粗标记不完整")?
            .trim()
    } else {
        value
    };
    let captures = pattern
        .captures(value)
        .context("编号答案必须为选项代号，可附带括号或对错标注")?;
    let choice = &captures[1];
    let labels: HashSet<char> = question
        .options
        .iter()
        .filter_map(|option| option.trim().chars().next())
        .filter(char::is_ascii_uppercase)
        .collect();
    ensure!(
        labels.len() == question.options.len(),
        "题号 {id} 的选项代号不明确，无法解析纯文本答案"
    );
    ensure!(
        choice.chars().all(|label| labels.contains(&label)),
        "题号 {id} 的答案包含不存在的选项"
    );
    ensure!(
        matches!(question.kind.trim(), "多选题" | "【多选题】") || choice.len() == 1,
        "题号 {id} 的单选或判断题答案必须只有一个选项"
    );
    ensure!(
        choice.chars().collect::<HashSet<_>>().len() == choice.len(),
        "题号 {id} 的答案选项重复"
    );
    let annotation = captures
        .get(2)
        .or_else(|| captures.get(3))
        .or_else(|| captures.get(4))
        .map_or("", |value| value.as_str())
        .trim();
    if matches!(question.kind.trim(), "判断题" | "【判断题】") && !annotation.is_empty() {
        let truth = |value: &str| match value {
            "对" | "正确" => Some(true),
            "错" | "错误" => Some(false),
            _ => None,
        };
        let expected = truth(annotation).context("判断题的对错标注无法识别")?;
        let option = question
            .options
            .iter()
            .find_map(|option| option.trim().strip_prefix(choice))
            .expect("validated option label")
            .trim_start_matches(|character: char| {
                character.is_whitespace() || matches!(character, '.' | '．' | '、' | ':' | '：')
            })
            .trim();
        ensure!(
            truth(option) == Some(expected),
            "题号 {id} 的选项代号与对错标注不一致"
        );
    }
    Ok(AnswerItem {
        index: id.to_owned(),
        explanation: if notes.is_empty() { annotation } else { notes }.to_owned(),
        content: choice.to_owned(),
    })
}

fn parse_numbered_choices(text: &str, questions: &[Question]) -> Result<Vec<AnswerItem>> {
    ensure!(
        !questions.is_empty()
            && questions.iter().all(|question| {
                matches!(
                    question.kind.trim(),
                    "单选题" | "【单选题】" | "多选题" | "【多选题】" | "判断题" | "【判断题】"
                ) && !question.options.is_empty()
            }),
        "模型未返回答案 JSON；纯文本仅支持单道无选项简答题或带原题号的选择题答案"
    );
    let pattern = regex::Regex::new(r"^([A-Z]+)(?:\s*(?:（([^（）]*)）|\(([^()]*)\)|(对|错)))?$")?;
    let mut current = Vec::new();
    let mut canonical = None;
    let mut table = false;
    let mut separator_expected = false;
    let mut explanation = false;

    for line in text.lines().map(str::trim).filter(|line| !line.is_empty()) {
        // Markdown 分隔线（---、***、___）不是答案内容。
        if line
            .chars()
            .all(|character| matches!(character, '-' | '*' | '_' | '='))
        {
            continue;
        }
        if separator_expected {
            let (first, second) = table_cells(line).context("答案表格缺少分隔行")?;
            ensure!(
                [first, second].iter().all(|cell| {
                    let cell = cell.trim_matches(':');
                    cell.len() >= 3 && cell.bytes().all(|byte| byte == b'-')
                }),
                "答案表格的分隔行无效"
            );
            separator_expected = false;
            table = true;
            continue;
        }
        if let Some(body) = section_body(line, &["答案", "参考答案", "答案如下", "汇总"])
        {
            finish_choice_block(&mut current, &mut canonical, questions)?;
            explanation = false;
            table = false;
            if !body.is_empty() {
                let body = body.strip_suffix('。').unwrap_or(body);
                let body = if body.starts_with("**") || body.ends_with("**") {
                    body.strip_prefix("**")
                        .and_then(|body| body.strip_suffix("**"))
                        .context("答案摘要的 Markdown 加粗标记不完整")?
                } else {
                    body
                };
                for item in body.split(['；', ';']) {
                    let segments = numbered_segments(item);
                    ensure!(!segments.is_empty(), "答案摘要缺少原题号");
                    for (id, value) in segments {
                        current.push(numbered_choice(id, value, questions, &pattern)?);
                    }
                }
                finish_choice_block(&mut current, &mut canonical, questions)?;
            }
            continue;
        }
        if section_body(
            line,
            &["简析", "简要解析", "简要说明", "解析", "说明", "分析"],
        )
        .is_some()
        {
            finish_choice_block(&mut current, &mut canonical, questions)?;
            explanation = true;
            table = false;
            continue;
        }
        // Only explicit answer sections are parsed; prose in the explanation is not an answer.
        if explanation {
            continue;
        }
        if table_cells(line) == Some(("题号", "答案")) {
            finish_choice_block(&mut current, &mut canonical, questions)?;
            separator_expected = true;
            continue;
        }
        if table {
            let (id, value) = table_cells(line).context("答案表格必须包含题号与答案两列")?;
            current.push(numbered_choice(id, value, questions, &pattern)?);
            continue;
        }
        let segments = numbered_segments(line);
        ensure!(!segments.is_empty(), "编号答案缺少原题号: {line}");
        for (id, value) in segments {
            current.push(numbered_choice(id, value, questions, &pattern)?);
        }
    }
    ensure!(!separator_expected, "答案表格缺少分隔行");
    finish_choice_block(&mut current, &mut canonical, questions)?;
    canonical.context("未读取到完整的编号答案区块")
}

fn validate_answers(
    mut answers: Vec<AnswerItem>,
    questions: &[Question],
) -> Result<Vec<AnswerItem>> {
    ensure!(
        answers.len() == questions.len(),
        "答案数量不匹配: 预期 {} 个，实际 {} 个",
        questions.len(),
        answers.len()
    );

    let expected: HashSet<&str> = questions
        .iter()
        .map(|question| question.id.as_str())
        .collect();
    let mut seen = HashSet::new();
    for answer in &answers {
        ensure!(
            expected.contains(answer.index.as_str()),
            "答案题号不匹配: {}",
            answer.index
        );
        ensure!(
            seen.insert(answer.index.as_str()),
            "答案题号重复: {}",
            answer.index
        );
        ensure!(
            !answer.content.trim().is_empty(),
            "题号 {} 的答案内容为空",
            answer.index
        );
    }

    // The frontend fills by array position, so explicit IDs must be restored to question order.
    answers.sort_by_key(|answer| {
        questions
            .iter()
            .position(|question| question.id == answer.index)
            .expect("validated question id")
    });
    Ok(answers)
}

#[cfg(test)]
#[path = "../../../../tests/unit/core/quiz/llm/parse.rs"]
mod tests;
