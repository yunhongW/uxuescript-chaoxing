use super::parse::parse_answers;
use super::{AnswerItem, SYSTEM_PROMPT};
use crate::config::llm::{LLMProtocol, LLMProvider};
use crate::core::quiz::html::Question;

use anyhow::Result;
use reqwest::header::{ACCEPT, HeaderMap, HeaderValue};
use std::sync::Arc;
use tokio::sync::Semaphore;

const CHUNK_SIZE: usize = 5;
const MAX_CONCURRENCY: usize = 10;

/// LLM 求解入口分发器
pub async fn solve(provider: &LLMProvider, questions: Vec<Question>) -> Result<Vec<AnswerItem>> {
    let chosen_model = provider
        .chosen_model
        .and_then(|idx| provider.models.get(idx))
        .ok_or_else(|| anyhow::anyhow!("未为提供商 [{}] 选择有效模型", provider.name))?;

    log::debug!(
        "将使用 [{}] 提供商模型 [{}] 进行推理 (题目总数: {}, 分组大小: {}, 最大并发: {})",
        provider.name,
        chosen_model,
        questions.len(),
        CHUNK_SIZE,
        MAX_CONCURRENCY
    );

    if questions.is_empty() {
        return Ok(Vec::new());
    }

    let client = reqwest::Client::builder()
        .user_agent(concat!("uXueScript/", env!("CARGO_PKG_VERSION")))
        .default_headers(HeaderMap::from_iter([(
            ACCEPT,
            HeaderValue::from_static("application/json"),
        )]))
        .build()?;
    let semaphore = Arc::new(Semaphore::new(MAX_CONCURRENCY));
    let mut handles = Vec::new();

    for chunk in questions.chunks(CHUNK_SIZE) {
        let client = client.clone();
        let provider = provider.clone();
        let model = chosen_model.to_string();
        let chunk = chunk.to_vec();
        let permit = semaphore.clone().acquire_owned().await?;

        handles.push(tokio::spawn(async move {
            let res = match provider.protocol {
                LLMProtocol::OpenAIChatCompletions => {
                    chat_completions(&client, &provider, &model, &chunk).await
                }
                LLMProtocol::OpenAIResponses => responses(&client, &provider, &model, &chunk).await,
                LLMProtocol::GoogleGemini => gemini(&client, &provider, &model, &chunk).await,
            };
            drop(permit);
            res
        }));
    }

    let mut all_answers = Vec::with_capacity(questions.len());
    for handle in handles {
        let chunk_answers = handle.await??;
        all_answers.extend(chunk_answers);
    }

    Ok(all_answers)
}

/// 仅对 HTTP 429 最多重试三次（含首次共四次请求）。
/// Retry-After 只解析整数秒，缺失或解析失败时依次等待 1、2、4 秒；
/// 网络发送错误直接返回，其他状态及最终响应交由协议处理函数判断。
async fn send_with_retry<F>(build_req: F) -> Result<reqwest::Response>
where
    F: Fn() -> reqwest::RequestBuilder,
{
    const MAX_RETRIES: u32 = 3;

    for retry in 0..MAX_RETRIES {
        let res = build_req().send().await?;

        if res.status() == reqwest::StatusCode::TOO_MANY_REQUESTS {
            let delay = res
                .headers()
                .get("retry-after")
                .and_then(|h| h.to_str().ok()?.parse().ok())
                .map(std::time::Duration::from_secs)
                .unwrap_or_else(|| std::time::Duration::from_millis(1000 * (1 << retry)));

            log::warn!(
                "触发 API 限流 (429)，将在 {:?} 后进行第 {}/{} 次重试...",
                delay,
                retry + 1,
                MAX_RETRIES
            );
            tokio::time::sleep(delay).await;
            continue;
        }
        return Ok(res);
    }

    Ok(build_req().send().await?)
}

/// 通用 OpenAI ChatCompletions 接口处理
async fn chat_completions(
    client: &reqwest::Client,
    provider: &LLMProvider,
    model: &str,
    questions: &[Question],
) -> Result<Vec<AnswerItem>> {
    let mut request_body: serde_json::Value =
        serde_json::from_str(include_str!("./req_body/default.json"))?;
    request_body["model"] = serde_json::json!(model);
    request_body["messages"] = serde_json::json!([
        { "role": "system", "content": SYSTEM_PROMPT },
        { "role": "user", "content": serde_json::to_string(questions)? }
    ]);

    if let Some(extra) = &provider.extra_body
        && let (Some(req_obj), Some(extra_obj)) = (request_body.as_object_mut(), extra.as_object())
    {
        for (k, v) in extra_obj {
            req_obj.insert(k.clone(), v.clone());
        }
    }

    let response = send_with_retry(|| {
        let mut req = client.post(&provider.base_url);
        if let Some(key) = provider.api_key.as_ref().map(|key| key.expose())
            && !key.trim().is_empty()
        {
            req = req.header("Authorization", format!("Bearer {}", key));
        }
        req.header("Content-Type", "application/json")
            .json(&request_body)
    })
    .await?;

    if !response.status().is_success() {
        anyhow::bail!(
            "{} API 错误 ({}): {}",
            provider.name,
            response.status(),
            response.text().await?
        );
    }

    let data: serde_json::Value = response.json().await?;
    let content = data
        .pointer("/choices/0/message/content")
        .or_else(|| data.pointer("/message/content"))
        .and_then(|v| v.as_str())
        .ok_or_else(|| {
            anyhow::anyhow!("无法从 {} 响应提取文本。原始响应: {}", provider.name, data)
        })?;

    parse_answers(content, questions).map_err(|e| {
        anyhow::anyhow!(
            "从 {} 响应解析答案 JSON 失败: {}。原始返回文本: {}",
            provider.name,
            e,
            content
        )
    })
}

/// OpenAI /v1/responses 接口处理
async fn responses(
    client: &reqwest::Client,
    provider: &LLMProvider,
    model: &str,
    questions: &[Question],
) -> Result<Vec<AnswerItem>> {
    let mut request_body: serde_json::Value =
        serde_json::from_str(include_str!("./req_body/openai.json"))?;
    request_body["model"] = serde_json::json!(model);
    request_body["instructions"] = serde_json::json!(SYSTEM_PROMPT);
    request_body["input"] = serde_json::json!(serde_json::to_string(questions)?);

    let response = send_with_retry(|| {
        let mut req = client.post(&provider.base_url);
        if let Some(key) = provider.api_key.as_ref().map(|key| key.expose())
            && !key.trim().is_empty()
        {
            req = req.header("Authorization", format!("Bearer {}", key));
        }
        req.header("Content-Type", "application/json")
            .json(&request_body)
    })
    .await?;

    if !response.status().is_success() {
        anyhow::bail!(
            "OpenAI API 错误 ({}): {}",
            response.status(),
            response.text().await?
        );
    }

    let data: serde_json::Value = response.json().await?;
    let content = data
        .pointer("/output/1/content/0/text")
        .and_then(|v| v.as_str())
        .or_else(|| {
            data["output"]
                .as_array()?
                .iter()
                .find(|o| o["type"] == "message")?
                .pointer("/content/0/text")?
                .as_str()
        })
        .ok_or_else(|| anyhow::anyhow!("无法从 OpenAI 响应提取文本。原始响应: {}", data))?;

    parse_answers(content, questions).map_err(|e| {
        anyhow::anyhow!(
            "从 OpenAI 响应解析答案 JSON 失败: {}。原始返回文本: {}",
            e,
            content
        )
    })
}

/// Google Gemini :generateContent 接口处理
async fn gemini(
    client: &reqwest::Client,
    provider: &LLMProvider,
    model: &str,
    questions: &[Question],
) -> Result<Vec<AnswerItem>> {
    let mut body: serde_json::Value = serde_json::from_str(include_str!("./req_body/google.json"))?;
    body["contents"] = serde_json::json!([{
        "parts": [{ "text": serde_json::to_string(questions)? }]
    }]);
    body["systemInstruction"] = serde_json::json!({
        "parts": [{ "text": SYSTEM_PROMPT }]
    });

    let url = format!("{}/{}:generateContent", provider.base_url, model);
    let response = send_with_retry(|| {
        let mut req = client.post(&url);
        if let Some(key) = provider.api_key.as_ref().map(|key| key.expose())
            && !key.trim().is_empty()
        {
            req = req.header("x-goog-api-key", key);
        }
        req.header("Content-Type", "application/json").json(&body)
    })
    .await?;

    if !response.status().is_success() {
        anyhow::bail!(
            "Google API 错误 ({}): {}",
            response.status(),
            response.text().await?
        );
    }

    let data: serde_json::Value = response.json().await?;
    let content = data
        .pointer("/candidates/0/content/parts/0/text")
        .and_then(|v| v.as_str())
        .ok_or_else(|| anyhow::anyhow!("无法从 Google 响应提取文本。原始响应: {}", data))?;

    parse_answers(content, questions).map_err(|e| {
        anyhow::anyhow!(
            "从 Google 响应解析答案 JSON 失败: {}。原始返回文本: {}",
            e,
            content
        )
    })
}

#[cfg(test)]
#[path = "../../../../tests/unit/core/quiz/llm/dispatcher.rs"]
mod tests;

#[cfg(test)]
#[path = "../../../../tests/live/core/quiz/llm/dispatcher.rs"]
mod live_tests;
