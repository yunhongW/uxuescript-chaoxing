import { flushPromises } from "@vue/test-utils";
import { afterEach, describe, expect, it, vi } from "vitest";
import { loadCore } from "../support/core";

type ChapterState = "Interactive" | "Finished" | "Blocking";

afterEach(() => vi.useRealTimers());

function setState(chapter: HTMLElement, state: ChapterState) {
  const name = chapter.querySelector<HTMLElement>(".posCatalog_name")!;
  name.onclick = state === "Blocking" ? null : () => {};
  chapter.querySelector(".orangeNew")?.remove();
  if (state !== "Finished") {
    const marker = chapter.ownerDocument.createElement("span");
    marker.className = "orangeNew";
    chapter.appendChild(marker);
  }
}

function setup(
  onChapter?: (chapter: HTMLElement) => void | Promise<void>,
  href = "https://mooc1.chaoxing.com/mycourse/studentstudy?mooc2=1&newMooc=true",
  overrides: Parameters<typeof loadCore>[1] = {},
) {
  vi.useFakeTimers();
  const course = document.implementation.createHTMLDocument();
  const location = { href, replace: vi.fn() };
  const invoke = vi.fn(
    async (command: string, _args?: Record<string, unknown>) =>
      command === "options" ? {} : true,
  );
  const chapterHandler = vi.fn(async (chapter: HTMLElement) => {
    await onChapter?.(chapter);
  });
  const console = { info: vi.fn(), error: vi.fn() };
  const api = loadCore(
    {
      document: course,
      URL,
      window: {
        __TAURI_INTERNALS__: { invoke },
        setTimeout: window.setTimeout.bind(window),
        location,
      },
      console,
    },
    {
      preserveFocusState: () => {},
      handleChapter: chapterHandler,
      ...overrides,
    },
  );
  const add = (id: string, state: ChapterState) => {
    const chapter = course.createElement("div");
    chapter.className = "posCatalog_select";
    chapter.id = id;
    const name = chapter.appendChild(course.createElement("span"));
    name.className = "posCatalog_name";
    name.textContent = id;
    name.title = id;
    course.body.appendChild(chapter);
    setState(chapter, state);
    return chapter;
  };
  const statuses = () =>
    invoke.mock.calls
      .filter(([command]) => command === "send_status")
      .map(([, args]) => (args?.status as { kind: string }).kind);
  const confirmations = () =>
    invoke.mock.calls
      .filter(([command]) => command === "confirm")
      .map(([, args]) => args?.message);
  return {
    course,
    api,
    invoke,
    chapterHandler,
    console,
    location,
    add,
    statuses,
    confirmations,
  };
}

function addLegacyCatalog(course: Document) {
  const chapter = course.createElement("div");
  chapter.className = "ncells";
  course.body.appendChild(chapter);
}

async function settle(run: Promise<void>, milliseconds = 15000) {
  await flushPromises();
  await vi.advanceTimersByTimeAsync(milliseconds);
  await run;
}

function expectCancelled(page: ReturnType<typeof setup>, cause: RegExp) {
  expect(page.statuses()).toContain("cancel");
  expect(page.statuses()).not.toContain("finish");
  expect(page.confirmations()).toHaveLength(2);
  const message = page.confirmations()[1];
  expect(typeof message).toBe("string");
  expect(String(message).split("\n\n")[0]).toMatch(cause);
}

describe("course chapter recognition", () => {
  it.each<ChapterState>(["Interactive", "Finished", "Blocking"])(
    "recognizes a %s chapter",
    (state) => {
      const page = setup();
      const chapter = page.add("chapter", state);
      expect(page.api.chapterNodeStatus(chapter)).toBe(state);
      expect(page.api.totalChapterList()).toEqual([chapter]);
    },
  );

  it("ignores catalog titles while retaining real chapters", () => {
    const page = setup();
    const heading = page.course.createElement("div");
    heading.className = "posCatalog_select";
    heading.appendChild(page.course.createElement("span")).className =
      "posCatalog_title";
    page.course.body.appendChild(heading);
    const chapter = page.add("chapter", "Interactive");
    expect(page.api.chapterNodeStatus(heading)).toBe("Title");
    expect(page.api.totalChapterList()).toEqual([chapter]);
  });

  it("rejects unknown catalog rows even beside a finished chapter", () => {
    const page = setup();
    page.add("complete", "Finished");
    const unknown = page.course.createElement("div");
    unknown.className = "posCatalog_select";
    page.course.body.appendChild(unknown);
    expect(page.api.chapterNodeStatus(unknown)).toBe("Unknown");
    expect(() => page.api.totalChapterList()).toThrow();
  });
});

describe("legacy course navigation", () => {
  it.each(["/mycourse/studentstudy", "/mooc-ans/mycourse/studentstudy"])(
    "opens the modern course from %s while retaining course parameters and the fragment",
    (path) => {
      const page = setup(
        undefined,
        `https://mooc1-2.chaoxing.com${path}?courseId=123&clazzid=456&cpi=789&mooc2=0&newMooc=false&enc=value%2Btoken&tag=one&tag=two#chapter-2`,
      );
      addLegacyCatalog(page.course);

      expect(page.api.switchToModernCourse()).toBe(true);
      expect(page.location.replace).toHaveBeenCalledExactlyOnceWith(
        "https://mooc1-2.chaoxing.com/mycourse/studentstudy?courseId=123&clazzid=456&cpi=789&mooc2=1&newMooc=true&enc=value%2Btoken&tag=one&tag=two#chapter-2",
      );
    },
  );

  it("uses the page's experience control before replacing the URL", () => {
    const page = setup(
      undefined,
      "https://mooc1.chaoxing.com/mooc-ans/mycourse/studentstudy?courseId=123",
    );
    addLegacyCatalog(page.course);
    const experience = page.course.createElement("a");
    experience.className = "experience";
    const click = vi.fn();
    experience.addEventListener("click", click);
    page.course.body.appendChild(experience);

    expect(page.api.switchToModernCourse()).toBe(true);
    expect(click).toHaveBeenCalledOnce();
    expect(page.location.replace).not.toHaveBeenCalled();
  });

  it("does not navigate when a modern catalog is already present", () => {
    const page = setup(
      undefined,
      "https://mooc1.chaoxing.com/mooc-ans/mycourse/studentstudy",
    );
    addLegacyCatalog(page.course);
    page.add("modern", "Finished");

    expect(page.api.switchToModernCourse()).toBe(false);
    expect(page.location.replace).not.toHaveBeenCalled();
  });

  it("does not navigate again when the URL already requests the modern page", () => {
    const page = setup();
    addLegacyCatalog(page.course);

    expect(page.api.switchToModernCourse()).toBe(false);
    expect(page.location.replace).not.toHaveBeenCalled();
  });

  it("does not navigate when no legacy catalog is present", () => {
    const page = setup(
      undefined,
      "https://mooc1.chaoxing.com/mooc-ans/mycourse/studentstudy",
    );

    expect(page.api.switchToModernCourse()).toBe(false);
    expect(page.location.replace).not.toHaveBeenCalled();
  });

  it.each([
    "/mooc-ans/mycourse/stu",
    "/mycourse/studentstudy/extra",
    "/mooc-ans/mycourse/",
  ])("does not rewrite the unrelated path %s", (path) => {
    const page = setup(
      undefined,
      `https://mooc1.chaoxing.com${path}?courseId=123`,
    );
    addLegacyCatalog(page.course);

    expect(page.api.switchToModernCourse()).toBe(false);
    expect(page.location.replace).not.toHaveBeenCalled();
  });

  it("cancels the current scan after navigation without reporting an error or completion", async () => {
    const page = setup(
      undefined,
      "https://mooc1.chaoxing.com/mooc-ans/mycourse/studentstudy?courseId=123",
    );
    addLegacyCatalog(page.course);

    await page.api.main();

    expect(page.location.replace).toHaveBeenCalledOnce();
    expect(page.statuses()).toEqual(["start", "cancel"]);
    expect(page.chapterHandler).not.toHaveBeenCalled();
    expect(page.confirmations()).toHaveLength(1);
    expect(page.console.error).not.toHaveBeenCalled();
    expect(vi.getTimerCount()).toBe(0);
  });

  it("stops with an error when the requested modern URL still has a legacy catalog", async () => {
    const page = setup();
    addLegacyCatalog(page.course);

    await page.api.main();

    expectCancelled(page, /未读取到课程章节/);
    expect(page.location.replace).not.toHaveBeenCalled();
    expect(page.chapterHandler).not.toHaveBeenCalled();
  });
});

describe("course completion", () => {
  it("cancels after waiting for an absent chapter catalog", async () => {
    const page = setup();
    await settle(page.api.main());
    expectCancelled(page, /未读取到课程目录/);
    expect(page.chapterHandler).not.toHaveBeenCalled();
  });

  it("waits for a chapter catalog that appears after startup", async () => {
    const page = setup((chapter) => setState(chapter, "Finished"));
    const run = page.api.main();
    await flushPromises();
    expect(page.chapterHandler).not.toHaveBeenCalled();
    window.setTimeout(() => page.add("delayed", "Interactive"), 500);
    await settle(run);
    expect(page.chapterHandler).toHaveBeenCalledOnce();
    expect(page.statuses()).toContain("finish");
    expect(page.statuses()).not.toContain("cancel");
    expect(page.confirmations()).toHaveLength(1);
  });

  it("cancels when only catalog titles are recognized", async () => {
    const page = setup();
    const heading = page.course.createElement("div");
    heading.className = "posCatalog_select";
    heading.appendChild(page.course.createElement("span")).className =
      "posCatalog_title";
    page.course.body.appendChild(heading);
    await settle(page.api.main());
    expectCancelled(page, /未读取到课程章节/);
    expect(page.chapterHandler).not.toHaveBeenCalled();
  });

  it("cancels when the catalog contains an unknown row", async () => {
    const page = setup();
    page.add("complete", "Finished");
    const unknown = page.course.createElement("div");
    unknown.className = "posCatalog_select";
    page.course.body.appendChild(unknown);
    await settle(page.api.main());
    expectCancelled(page, /课程目录中有无法识别的章节/);
    expect(page.chapterHandler).not.toHaveBeenCalled();
  });

  it("finishes a nonempty catalog whose chapters are all complete", async () => {
    const page = setup();
    page.add("complete", "Finished");
    await settle(page.api.main());
    expect(page.statuses()).toContain("finish");
    expect(page.statuses()).not.toContain("cancel");
    expect(page.chapterHandler).not.toHaveBeenCalled();
    expect(page.confirmations()).toHaveLength(1);
    expect(page.invoke).toHaveBeenCalledWith("send_status", {
      status: {
        kind: "chapter",
        payload: { title: "complete", index: 0, completed: 1, total: 1 },
      },
    });
  });

  it("processes an unfinished chapter after an already finished chapter", async () => {
    const page = setup((chapter) => setState(chapter, "Finished"));
    page.add("complete", "Finished");
    const unfinished = page.add("unfinished", "Interactive");
    await settle(page.api.main());
    expect(page.chapterHandler).toHaveBeenCalledExactlyOnceWith(unfinished);
    expect(page.statuses()).toContain("finish");
    expect(page.statuses()).not.toContain("cancel");
  });

  it("continues while completed chapters increase", async () => {
    let laterAttempts = 0;
    const page = setup((chapter) => {
      if (chapter.id === "first" || ++laterAttempts === 2) {
        setState(chapter, "Finished");
      }
    });
    page.add("first", "Interactive");
    const later = page.add("later", "Interactive");
    await settle(page.api.main());
    expect(page.chapterHandler).toHaveBeenCalledTimes(3);
    expect(page.chapterHandler).toHaveBeenLastCalledWith(later);
    expect(page.statuses()).toContain("finish");
    expect(page.statuses()).not.toContain("cancel");
  });

  it("waits for delayed completion and unlocking after two stalled passes", async () => {
    let updateScheduled = false;
    const page = setup((chapter) => {
      if (chapter.id === "first") {
        if (!updateScheduled) {
          updateScheduled = true;
          window.setTimeout(() => {
            setState(chapter, "Finished");
            setState(later, "Interactive");
          }, 11000);
        }
      } else {
        setState(chapter, "Finished");
      }
    });
    page.add("first", "Interactive");
    const later = page.add("later", "Blocking");

    await settle(page.api.main(), 25000);

    expect(page.chapterHandler).toHaveBeenCalledTimes(4);
    expect(page.chapterHandler).toHaveBeenLastCalledWith(later);
    expect(page.statuses()).toContain("finish");
    expect(page.statuses()).not.toContain("cancel");
    expect(page.console.info).toHaveBeenCalledWith(
      "等待课程目录同步，准备重试（2/3）",
    );
  });

  it("resets stalled passes when a chapter completes", async () => {
    const attempts = { first: 0, later: 0 };
    const page = setup((chapter) => {
      const id = chapter.id as keyof typeof attempts;
      attempts[id] += 1;
      if (attempts[id] === (id === "first" ? 3 : 6)) {
        setState(chapter, "Finished");
      }
    });
    page.add("first", "Interactive");
    page.add("later", "Interactive");

    await settle(page.api.main(), 35000);

    expect(attempts).toEqual({ first: 3, later: 6 });
    expect(page.chapterHandler).toHaveBeenCalledTimes(9);
    expect(page.statuses()).toContain("finish");
    expect(page.statuses()).not.toContain("cancel");
    expect(vi.getTimerCount()).toBe(0);
  });

  it("continues when a blocked chapter unlocks without a completion increase", async () => {
    const page = setup((chapter) => setState(chapter, "Finished"));
    const chapter = page.add("locked", "Blocking");
    const run = page.api.main();
    await flushPromises();
    expect(page.chapterHandler).not.toHaveBeenCalled();
    window.setTimeout(() => setState(chapter, "Interactive"), 2500);
    await settle(run);
    expect(page.chapterHandler).toHaveBeenCalledExactlyOnceWith(chapter);
    expect(page.statuses()).toContain("finish");
    expect(page.statuses()).not.toContain("cancel");
  });

  it("continues when an additional chapter appears during a pass", async () => {
    let firstAttempts = 0;
    const page = setup((chapter) => {
      if (chapter.id === "first" && ++firstAttempts === 1) {
        page.add("additional", "Interactive");
      } else {
        setState(chapter, "Finished");
      }
    });
    page.add("first", "Interactive");
    await settle(page.api.main());
    expect(page.chapterHandler).toHaveBeenCalledTimes(3);
    expect(page.api.totalChapterList()).toHaveLength(2);
    expect(page.statuses()).toContain("finish");
    expect(page.statuses()).not.toContain("cancel");
  });

  it.each<ChapterState>(["Interactive", "Blocking"])(
    "cancels without retrying indefinitely when %s chapters make no progress",
    async (state) => {
      const page = setup();
      page.add("pending", state);
      await settle(page.api.main());
      expectCancelled(page, /连续 3 轮未取得进展/);
      expect(page.chapterHandler).toHaveBeenCalledTimes(
        state === "Interactive" ? 3 : 0,
      );
      expect(vi.getTimerCount()).toBe(0);
    },
  );

  it("reports an unsuccessful chapter handler without finishing the course", async () => {
    const failure = new Error("Video playback failed");
    const page = setup(() => {
      throw failure;
    });
    page.add("pending", "Interactive");
    await settle(page.api.main());
    expectCancelled(page, /本轮任务处理失败/);
    expect(page.confirmations()[1]).toContain("Video playback failed");
    expect(page.chapterHandler).toHaveBeenCalledOnce();
    expect(page.console.error).toHaveBeenCalledWith(
      "章节处理失败，自动跳过该章节",
      failure,
    );
  });

  it.each([false, true])(
    "does not retry a failed Quiz after continuing the pass (catalog finished: %s)",
    async (catalogFinished) => {
      const quiz = vi.fn(async () => {
        throw new Error("模型未返回答案 JSON");
      });
      const pdf = vi.fn(async () => {});
      const tasks = document.implementation.createHTMLDocument();
      for (const kind of ["work", "pdf"]) {
        const container = tasks.createElement("div");
        container.className = "ans-attach-ct";
        container.appendChild(tasks.createElement("span")).className =
          "ans-job-icon";
        const iframe = container.appendChild(tasks.createElement("iframe"));
        Object.defineProperty(iframe, "contentDocument", {
          value: {
            location: {
              href: `https://example.com/ananas/modules/${kind}/index.html`,
            },
            body: { children: [{}] },
          },
        });
        tasks.body.appendChild(container);
      }
      const page = setup(
        async (chapter) => {
          if (chapter.id === "failed") await page.api.handleTab(tasks);
          if (chapter.id !== "failed" || catalogFinished)
            setState(chapter, "Finished");
        },
        undefined,
        { handleQuiz: quiz, handlePDF: pdf },
      );
      page.api.wait.taskPointComplete = vi.fn(async () => true);
      page.add("failed", "Interactive");
      page.add("later", "Interactive");

      await settle(page.api.main());

      expect(quiz).toHaveBeenCalledOnce();
      expect(pdf).toHaveBeenCalledOnce();
      expect(page.chapterHandler).toHaveBeenCalledTimes(2);
      expectCancelled(page, /本轮任务处理失败/);
      expect(page.confirmations()[1]).toContain("模型未返回答案 JSON");
      expect(page.console.info).not.toHaveBeenCalledWith(
        expect.stringContaining("等待课程目录同步"),
      );
      expect(vi.getTimerCount()).toBe(0);
    },
  );

  it("cancels when the chapter catalog disappears during processing", async () => {
    const page = setup(() => page.course.body.replaceChildren());
    page.add("pending", "Interactive");
    await settle(page.api.main());
    expectCancelled(page, /未读取到课程章节/);
    expect(page.chapterHandler).toHaveBeenCalledOnce();
  });

  it("does not finish when an unfinished row disappears beside a finished row", async () => {
    const page = setup((chapter) => chapter.remove());
    page.add("complete", "Finished");
    page.add("pending", "Interactive");
    await settle(page.api.main());
    expectCancelled(page, /章节数量减少/);
    expect(page.chapterHandler).toHaveBeenCalledOnce();
  });
});

describe("debug course scans", () => {
  it("allows a confirmed debug error without stopping for a normal-mode failure", async () => {
    const page = setup(() => {
      throw new Error("Debug task failed");
    });
    page.add("pending", "Interactive");
    page.api.config.debugTaskTypes = ["Quiz"];

    await page.api.main();

    expect(page.chapterHandler).toHaveBeenCalledOnce();
    expect(page.statuses()).toContain("cancel");
    expect(page.statuses()).not.toContain("finish");
    expect(page.confirmations()).toHaveLength(2);
    expect(page.confirmations()[1]).toContain("[DEBUG 异常]");
    expect(page.confirmations()[1]).not.toContain("[运行已停止]");
    expect(vi.getTimerCount()).toBe(0);
  });

  it("scans unfinished chapters once without waiting or reporting course completion", async () => {
    const page = setup();
    page.add("pending", "Interactive");
    page.add("locked", "Blocking");
    page.api.config.debugTaskTypes = ["Video"];
    await page.api.main();
    expect(page.chapterHandler).toHaveBeenCalledTimes(2);
    expect(page.statuses()).toContain("cancel");
    expect(page.statuses()).not.toContain("finish");
    expect(page.confirmations()).toHaveLength(1);
    expect(page.console.error).not.toHaveBeenCalled();
    expect(vi.getTimerCount()).toBe(0);
  });

  it("finishes a debug scan when every chapter is already complete", async () => {
    const page = setup();
    page.add("complete", "Finished");
    page.api.config.debugTaskTypes = ["Video"];
    await page.api.main();
    expect(page.chapterHandler).toHaveBeenCalledOnce();
    expect(page.statuses()).toContain("finish");
    expect(page.statuses()).not.toContain("cancel");
    expect(page.confirmations()).toHaveLength(1);
    expect(vi.getTimerCount()).toBe(0);
  });

  it("updates final debug progress when the scan completes the last chapter", async () => {
    const page = setup((chapter) => setState(chapter, "Finished"));
    page.add("pending", "Interactive");
    page.api.config.debugTaskTypes = ["Video"];
    await page.api.main();
    expect(page.invoke).toHaveBeenCalledWith("send_status", {
      status: {
        kind: "chapter",
        payload: { title: "pending", index: 0, completed: 1, total: 1 },
      },
    });
    expect(page.statuses()).toContain("finish");
    expect(page.statuses()).not.toContain("cancel");
    expect(page.confirmations()).toHaveLength(1);
  });
});
