use super::*;
use serde_json::json;

fn question(id: &str) -> Question {
    Question {
        id: id.into(),
        kind: "简答题".into(),
        stem: "为什么天空是蓝色的？".into(),
        options: Vec::new(),
    }
}

fn answer(id: &str, content: &str) -> Value {
    json!({"index": id, "explanation": "", "content": content})
}

fn choice_question(id: &str) -> Question {
    Question {
        id: id.into(),
        kind: "【判断题】".into(),
        stem: "判断以下表述。".into(),
        options: vec!["A 对".into(), "B 错".into()],
    }
}

#[test]
fn parses_answer_array() {
    let answers = parse_answers(
        &json!([answer("1", "蓝光散射更强")]).to_string(),
        &[question("1")],
    )
    .unwrap();

    assert_eq!(answers.len(), 1);
    assert_eq!(answers[0].index, "1");
    assert_eq!(answers[0].content, "蓝光散射更强");
}

#[test]
fn parses_whole_markdown_json_blocks() {
    for header in ["```json", "```JSON", "```"] {
        let text = format!(" \r\n{header}\r\n[{}]\r\n```\r\n", answer("1", "蓝光"));
        let answers = parse_answers(&text, &[question("1")]).unwrap();
        assert_eq!(answers[0].content, "蓝光");
    }
}

#[test]
fn parses_answers_wrapper() {
    let text = json!({"answers": [answer("1", "蓝光")]}).to_string();
    let answers = parse_answers(&text, &[question("1")]).unwrap();
    assert_eq!(answers[0].content, "蓝光");
}

#[test]
fn parses_fenced_answers_wrapper() {
    let text = format!(
        "```json\n{}\n```",
        json!({"answers": [answer("1", "蓝光")]})
    );
    let answers = parse_answers(&text, &[question("1")]).unwrap();
    assert_eq!(answers[0].index, "1");
}

#[test]
fn parses_single_answer_object() {
    let answers = parse_answers(&answer("7", "蓝光").to_string(), &[question("7")]).unwrap();
    assert_eq!(answers[0].index, "7");
    assert_eq!(answers[0].content, "蓝光");
}

#[test]
fn preserves_existing_answer_field_aliases() {
    for text in [
        r#"[{"题号":"1","解析":"散射","答案":"蓝光"}]"#,
        r#"{"id":"1","explanation":"散射","answer":"蓝光"}"#,
    ] {
        let answers = parse_answers(text, &[question("1")]).unwrap();
        assert_eq!(answers[0].index, "1");
        assert_eq!(answers[0].explanation, "散射");
        assert_eq!(answers[0].content, "蓝光");
    }
}

#[test]
fn accepts_original_plain_chinese_health_response() {
    let text = "因为太阳光进入大气层后，波长较短的蓝光被空气分子散射得比波长较长的光更强烈，所以天空呈蓝色";
    let answers = parse_answers(text, &[question("1")]).unwrap();

    assert_eq!(answers.len(), 1);
    assert_eq!(answers[0].index, "1");
    assert_eq!(answers[0].content, text);
    assert!(answers[0].explanation.is_empty());
}

#[test]
fn preserves_plain_text_and_uses_the_question_id() {
    let text = "\n  因为蓝光散射更强。\n";
    let answers = parse_answers(text, &[question("42")]).unwrap();
    assert_eq!(answers[0].index, "42");
    assert_eq!(answers[0].content, text);
}

#[test]
fn accepts_plain_text_for_html_short_answer_labels() {
    for kind in ["简答题", "【简答题】", "  【简答题】 "] {
        let mut item = question("7");
        item.kind = kind.into();
        let answers = parse_answers("蓝光散射更强", &[item]).unwrap();
        assert_eq!(answers[0].index, "7");
        assert_eq!(answers[0].content, "蓝光散射更强");
    }
}

#[test]
fn accepts_plain_text_starting_with_json_literal_letters() {
    for text in [
        "the sky looks blue because shorter wavelengths scatter more.",
        "for visible light, blue wavelengths scatter strongly.",
        "nitrogen molecules scatter sunlight.",
    ] {
        let answers = parse_answers(text, &[question("1")]).unwrap();
        assert_eq!(answers[0].content, text);
    }
}

#[test]
fn rejects_plain_text_for_multiple_questions() {
    let error = parse_answers("蓝光散射更强", &[question("1"), question("2")]).unwrap_err();
    assert!(error.to_string().contains("纯文本仅支持单道无选项简答题"));
}

#[test]
fn rejects_plain_text_for_other_question_kinds() {
    for kind in ["单选题", "多选题", "判断题", "填空题", "论述题"] {
        let mut item = question("1");
        item.kind = kind.into();
        let error = parse_answers("蓝光", &[item]).unwrap_err();
        assert!(error.to_string().contains("纯文本仅支持单道无选项简答题"));
    }
}

#[test]
fn rejects_plain_text_when_options_are_present() {
    let mut item = question("1");
    item.options = vec!["A 蓝光".into(), "B 红光".into()];
    assert!(parse_answers("蓝光", &[item]).is_err());
}

#[test]
fn accepts_observed_numbered_markdown_and_table_answer_blocks() {
    let questions = (36..=40)
        .map(|id| choice_question(&id.to_string()))
        .collect::<Vec<_>>();
    for text in [
        "36. A（对）  \n37. B（错）——碳达峰与碳中和概念颠倒。  \n38. B（错）——中央生态环境保护督察试点在河北，不是山西。  \n39. B（错）——我国第一部以“法典”命名的是《民法典》。  \n40. B（错）——应为世界上第一部以“生态环境”命名的法典。\n\n答案：36.A；37.B；38.B；39.B；40.B。",
        "答案：\n\n36. **A 对**  \n37. **B 错**  \n38. **B 错**  \n39. **B 错**  \n40. **B 错**\n\n简要解析：\n- 37：概念颠倒。\n- 38：地点不同。",
        "参考答案：\n\n| 题号 | 答案 |\n|---|---|\n| 36 | A 对 |\n| 37 | B 错 |\n| 38 | B 错 |\n| 39 | B 错 |\n| 40 | B 错 |\n\n简析：\n- 37：概念颠倒。",
        "答案如下：\n36. A（对）\n37. B（错）\n38. B（错）\n39. B（错）\n40. B（错）\n\n汇总：**36.A；37.B；38.B；39.B；40.B**",
    ] {
        let answers = parse_answers(text, &questions).unwrap();
        assert_eq!(answers.len(), questions.len());
        for (answer, question) in answers.iter().zip(&questions) {
            assert_eq!(answer.index, question.id);
            assert_eq!(answer.content, if question.id == "36" { "A" } else { "B" });
        }
    }
}

#[test]
fn accepts_the_reported_answer_block_with_a_brief_explanation() {
    let text = "答案：  \n36. A 对  \n37. B 错  \n38. B 错  \n39. B 错  \n40. B 错  \n\n简要说明：  \n- 37：碳达峰是排放量达到峰值后不再增长；碳中和是净零排放，题干定义颠倒。  \n- 38：中央生态环境保护督察试点最早在河北，不是山西。  \n- 39：我国第一部以“法典”命名的法律是《民法典》。  \n- 40：题干“第二部”表述错误。";
    let questions = (36..=40)
        .map(|id| choice_question(&id.to_string()))
        .collect::<Vec<_>>();
    let answers = parse_answers(text, &questions).unwrap();

    assert_eq!(answers.len(), 5);
    for (answer, question) in answers.iter().zip(&questions) {
        assert_eq!(answer.index, question.id);
        assert_eq!(answer.content, if question.id == "36" { "A" } else { "B" });
    }
}

#[test]
fn accepts_full_width_separators_and_inline_answers() {
    let questions = (36..=40)
        .map(|id| choice_question(&id.to_string()))
        .collect::<Vec<_>>();
    for text in [
        // 全角句点
        "答案：\n36．A 对\n37．B 错\n38．B 错\n39．B 错\n40．B 错\n\n简要说明：\n- 37：概念颠倒。",
        // 顿号 + 同一行内多个答案
        "答案：36、A 对 37、B 错 38、B 错 39、B 错 40、B 错",
        // 加粗标题与加粗解析标题
        "**答案：**\n36. A 对\n37. B 错\n38. B 错\n39. B 错\n40. B 错\n\n**解析：**\n- 37：概念颠倒。",
        // 半角冒号作分隔
        "答案：\n36:A 对\n37:B 错\n38:B 错\n39:B 错\n40:B 错\n\n分析：\n- 37：概念颠倒。",
    ] {
        let answers = parse_answers(text, &questions).unwrap();
        assert_eq!(answers.len(), questions.len());
        for (answer, question) in answers.iter().zip(&questions) {
            assert_eq!(answer.index, question.id);
            assert_eq!(answer.content, if question.id == "36" { "A" } else { "B" });
        }
    }
}

#[test]
fn accepts_inline_summary_with_multiple_answers() {
    let answers = parse_answers(
        "答案：36.A 37.B。",
        &[choice_question("36"), choice_question("37")],
    )
    .unwrap();
    assert_eq!(answers[0].content, "A");
    assert_eq!(answers[1].content, "B");
}

#[test]
fn ignores_horizontal_rules_between_answers() {
    let answers = parse_answers(
        "答案：\n36. A 对\n---\n37. B 错\n***\n",
        &[choice_question("36"), choice_question("37")],
    )
    .unwrap();
    assert_eq!(answers[0].content, "A");
    assert_eq!(answers[1].content, "B");
}

#[test]
fn repairs_strings_that_end_with_a_chinese_quote() {
    let text = "[\n{\n\"index\": \"81\",\n\"content\": \"关键领域\",\n\"explanation\": \"题干无错别字。人工智能被视为大国科技竞争的核心领域，故填“关键领域”。\n},\n{\n\"index\": \"82\",\n\"content\": \"B\",\n\"explanation\": \"全球治理并非建立世界政府，故选B。\"\n}\n]";
    let mut fill = question("81");
    fill.kind = "【填空题】".into();
    let answers = parse_answers(text, &[fill, choice_question("82")]).unwrap();

    assert_eq!(answers.len(), 2);
    assert_eq!(answers[0].index, "81");
    assert_eq!(answers[0].content, "关键领域");
    assert_eq!(answers[1].index, "82");
    assert_eq!(answers[1].content, "B");
}

#[test]
fn accepts_ascii_colons_in_explicit_answer_sections() {
    let text = "答案:\n36. **A 对**\n简要解析:\n- 36: 正确。";
    let answers = parse_answers(text, &[choice_question("36")]).unwrap();
    assert_eq!(answers[0].content, "A");
}

#[test]
fn restores_numbered_answers_to_the_original_question_order() {
    let answers = parse_answers(
        "40. B (错)\n\n36. A",
        &[choice_question("36"), choice_question("40")],
    )
    .unwrap();
    assert_eq!(answers[0].index, "36");
    assert_eq!(answers[0].content, "A");
    assert!(answers[0].explanation.is_empty());
    assert_eq!(answers[1].index, "40");
    assert_eq!(answers[1].content, "B");
    assert_eq!(answers[1].explanation, "错");
}

#[test]
fn restores_reversed_table_answers_to_the_original_question_order() {
    let answers = parse_answers(
        "| 题号 | 答案 |\n|---|---|\n| 40 | B 错 |\n| 36 | A 对 |",
        &[choice_question("36"), choice_question("40")],
    )
    .unwrap();
    assert_eq!(answers[0].index, "36");
    assert_eq!(answers[0].content, "A");
    assert_eq!(answers[1].index, "40");
    assert_eq!(answers[1].content, "B");
}

#[test]
fn accepts_consistent_complete_summaries_in_a_different_order() {
    let text = "36. A\n37. B\n\n答案：37.B；36.A。";
    let answers = parse_answers(text, &[choice_question("36"), choice_question("37")]).unwrap();
    assert_eq!(answers[0].index, "36");
    assert_eq!(answers[1].index, "37");
}

#[test]
fn accepts_numbered_multiple_choice_answers() {
    let mut item = choice_question("7");
    item.kind = "多选题".into();
    item.options.push("C 其他".into());
    let answers = parse_answers("7. AC", &[item]).unwrap();
    assert_eq!(answers[0].content, "AC");
}

#[test]
fn rejects_incomplete_answer_blocks_even_beside_a_complete_block() {
    let questions = [choice_question("36"), choice_question("37")];
    for text in [
        "36. A",
        "36. A\n37. B\n答案：36.A",
        "参考答案：\n| 题号 | 答案 |\n|---|---|\n| 36 | A 对 |",
    ] {
        let error = parse_answers(text, &questions).unwrap_err();
        assert!(error.to_string().contains("答案数量不匹配"));
    }
}

#[test]
fn rejects_additional_numbered_answers_without_truncating() {
    let error = parse_answers(
        "36. A\n37. B\n38. A",
        &[choice_question("36"), choice_question("37")],
    )
    .unwrap_err();
    assert!(error.to_string().contains("答案题号不匹配"));
}

#[test]
fn rejects_duplicate_ids_inside_a_numbered_block_or_summary() {
    let questions = [choice_question("36"), choice_question("37")];
    for text in ["36. A\n36. B", "答案：36.A；36.A"] {
        let error = parse_answers(text, &questions).unwrap_err();
        assert!(error.to_string().contains("答案题号重复"));
    }
}

#[test]
fn rejects_conflicting_complete_answer_blocks() {
    let questions = [choice_question("36"), choice_question("37")];
    for text in [
        "36. A\n37. B\n答案：36.B；37.B",
        "36. A\n37. B\n简析：\n- 36：解释。\n答案：36.B；37.B",
        "36. A\n37. B\n汇总：**36.B；37.B**",
    ] {
        let error = parse_answers(text, &questions).unwrap_err();
        assert!(error.to_string().contains("答案区块的内容不一致"));
    }
}

#[test]
fn rejects_unmatched_numbered_ids_without_reindexing() {
    for text in ["1. A", "036. A", "37. A"] {
        let error = parse_answers(text, &[choice_question("36")]).unwrap_err();
        assert!(error.to_string().contains("答案题号不匹配"));
    }
}

#[test]
fn rejects_numbered_answers_with_unknown_or_ambiguous_options() {
    let question = choice_question("36");
    for text in ["36. C", "36. AB"] {
        assert!(parse_answers(text, &[question.clone()]).is_err());
    }
    let mut question = question;
    question.options = vec!["对".into(), "错".into()];
    let error = parse_answers("36. A", &[question]).unwrap_err();
    assert!(error.to_string().contains("选项代号不明确"));
}

#[test]
fn rejects_judgment_annotations_that_conflict_with_the_selected_option() {
    for text in [
        "36. A（错）",
        "36. B 对",
        "36. **B 正确**",
        "36. A（应选B）",
    ] {
        assert!(parse_answers(text, &[choice_question("36")]).is_err());
    }
}

#[test]
fn accepts_matching_judgment_annotations_with_full_option_labels() {
    let mut item = choice_question("36");
    item.options = vec!["A. 正确".into(), "B. 错误".into()];
    let answers = parse_answers("36. A（对）", &[item]).unwrap();
    assert_eq!(answers[0].content, "A");
}

#[test]
fn rejects_repeated_letters_in_numbered_multiple_choice_answers() {
    let mut item = choice_question("36");
    item.kind = "【多选题】".into();
    let error = parse_answers("36. AA", &[item]).unwrap_err();
    assert!(error.to_string().contains("答案选项重复"));
}

#[test]
fn rejects_unrecognized_prose_outside_an_explanation_section() {
    for text in [
        "答案如下\n36. A",
        "36. A\n这道题的解释。",
        "36. A 因为正确",
        "36. A，因为正确",
    ] {
        assert!(parse_answers(text, &[choice_question("36")]).is_err());
    }
}

#[test]
fn rejects_incomplete_markdown_bold_markers() {
    for text in ["36. **A 对", "36. A 对**", "36. ***A 对***"] {
        assert!(parse_answers(text, &[choice_question("36")]).is_err());
    }
}

#[test]
fn does_not_extract_answers_from_explanation_prose() {
    for heading in ["简析", "简要解析", "简要说明"] {
        let answers = parse_answers(
            &format!("36. A\n37. B\n{heading}：\n36. B\n37. A"),
            &[choice_question("36"), choice_question("37")],
        )
        .unwrap();
        assert_eq!(answers[0].content, "A");
        assert_eq!(answers[1].content, "B");
        assert!(parse_answers(&format!("{heading}：\n36. A"), &[choice_question("36")]).is_err());
        assert!(
            parse_answers(
                &format!("36. A\n{heading}：\n37. B"),
                &[choice_question("36"), choice_question("37")]
            )
            .is_err()
        );
    }
}

#[test]
fn rejects_malformed_tables_and_missing_table_separators() {
    // 三列表格（题号/答案/解析）由 accepts_three_column_tables_with_an_explanation_column 覆盖。
    for text in [
        "| 题号 | 答案 |",
        "| 题号 | 答案 |\n| 36 | A |",
        "| 题号 | 答案 |\n|--|---|\n| 36 | A |",
    ] {
        assert!(parse_answers(text, &[choice_question("36")]).is_err());
    }
}

#[test]
fn accepts_three_column_tables_with_an_explanation_column() {
    let text = "| 题号 | 答案 | 解析 |\n| --- | --- | --- |\n| 36 | A | 蓝光散射更强 |\n| 37 | B | 红光穿透更强 |";
    let questions = [choice_question("36"), choice_question("37")];
    let answers = parse_answers(text, &questions).unwrap();
    assert_eq!(answers.len(), 2);
    assert_eq!(answers[0].content, "A");
    assert_eq!(answers[1].content, "B");
}

#[test]
fn rejects_obvious_json_damage_even_with_a_complete_numbered_block() {
    for text in [
        "36. A\n简析：\n[{\"index\":\"36\"",
        "```json\n36. A\n```",
        "答案：[{\"index\":\"36\",\"content\":\"A\"}",
    ] {
        assert!(parse_answers(text, &[choice_question("36")]).is_err());
    }
}

#[test]
fn rejects_mixed_question_types_for_numbered_choice_fallback() {
    assert!(parse_answers("36. A\n37. B", &[choice_question("36"), question("37")]).is_err());
}

#[test]
fn rejects_empty_responses() {
    for text in ["", " \r\n\t"] {
        let error = parse_answers(text, &[question("1")]).unwrap_err();
        assert!(error.to_string().contains("未返回答案文本"));
    }
}

#[test]
fn rejects_malformed_json_without_plain_text_fallback() {
    for text in [
        r#"[{"index":"1","explanation":"","content":"蓝光"}"#,
        r#"{"index":"1","explanation":"","content":"蓝光""#,
        r#""index":"1","content":"蓝光""#,
        r#"index: "1", content: "蓝光""#,
        r#"答案如下：[{"index":"1","explanation":"","content":"蓝光"}]"#,
    ] {
        assert!(
            parse_answers(text, &[question("1")]).is_err(),
            "malformed JSON was accepted: {text}"
        );
    }
}

#[test]
fn rejects_error_objects_and_wrong_wrapper_types() {
    for text in [
        r#"{"error":{"message":"模型暂时不可用"}}"#,
        r#"{"message":"余额不足"}"#,
        r#"{"answers":"蓝光"}"#,
        r#"{"answers":null}"#,
        r#"{"answers":{"index":"1","explanation":"","content":"蓝光"}}"#,
    ] {
        assert!(parse_answers(text, &[question("1")]).is_err());
    }
}

#[test]
fn rejects_json_scalars_and_wrong_item_field_types() {
    for text in [
        r#""蓝光""#,
        "null",
        "true",
        "42",
        r#"["蓝光"]"#,
        r#"[{"index":1,"explanation":"","content":"蓝光"}]"#,
        r#"[{"index":"1","explanation":"","content":["蓝光"]}]"#,
        r#"[{"index":"1","explanation":null,"content":"蓝光"}]"#,
    ] {
        assert!(parse_answers(text, &[question("1")]).is_err());
    }
}

#[test]
fn rejects_missing_answer_fields() {
    for text in [
        r#"{"content":"蓝光"}"#,
        r#"{"index":"1","content":"蓝光"}"#,
        r#"[{"index":"1","explanation":""}]"#,
    ] {
        assert!(parse_answers(text, &[question("1")]).is_err());
    }
}

#[test]
fn rejects_partial_or_surrounded_markdown_blocks() {
    for text in [
        "```json",
        "```json\n[]",
        "```json\n",
        "```json\n[]\n```\n补充说明",
        "说明\n```json\n[]\n```",
        "```text\n蓝光\n```",
    ] {
        assert!(parse_answers(text, &[question("1")]).is_err());
    }
}

#[test]
fn rejects_plain_text_inside_a_json_fence() {
    let error = parse_answers("```json\n蓝光散射更强\n```", &[question("1")]).unwrap_err();
    assert!(error.to_string().contains("JSON 解析失败"));
}

#[test]
fn rejects_mismatched_answer_counts() {
    for value in [
        json!([]),
        json!([answer("1", "蓝光"), answer("2", "红光")]),
        json!({"answers": []}),
    ] {
        let error = parse_answers(&value.to_string(), &[question("1")]).unwrap_err();
        assert!(error.to_string().contains("答案数量不匹配"));
    }
}

#[test]
fn rejects_duplicate_answer_ids() {
    let error = parse_answers(
        &json!([answer("1", "蓝光"), answer("1", "红光")]).to_string(),
        &[question("1"), question("2")],
    )
    .unwrap_err();
    assert!(error.to_string().contains("答案题号重复"));
}

#[test]
fn rejects_unknown_answer_ids() {
    let error =
        parse_answers(&json!([answer("2", "蓝光")]).to_string(), &[question("1")]).unwrap_err();
    assert!(error.to_string().contains("答案题号不匹配"));
}

#[test]
fn rejects_empty_answer_contents() {
    for content in ["", " \r\n\t"] {
        let error = parse_answers(&json!([answer("1", content)]).to_string(), &[question("1")])
            .unwrap_err();
        assert!(error.to_string().contains("答案内容为空"));
    }
}

#[test]
fn restores_json_answers_to_the_original_question_order() {
    let answers = parse_answers(
        &json!([answer("2", "红光"), answer("1", "蓝光")]).to_string(),
        &[question("1"), question("2")],
    )
    .unwrap();
    assert_eq!(answers[0].index, "1");
    assert_eq!(answers[0].content, "蓝光");
    assert_eq!(answers[1].index, "2");
    assert_eq!(answers[1].content, "红光");
}

// 后期测试补的回归：模型换排版时不再整题失败。
#[test]
fn plain_short_answer_keeps_reference_brackets() {
    let text = "答案见教材[3]第 42 页，蓝光散射更强";
    let answers = parse_answers(text, &[question("1")]).unwrap();
    assert_eq!(answers[0].index, "1");
    assert_eq!(answers[0].content, text);
}

#[test]
fn plain_short_answer_starting_with_analysis_label() {
    let text = "解析: 蓝光被散射";
    let answers = parse_answers(text, &[question("1")]).unwrap();
    assert_eq!(answers[0].content, text);
}

#[test]
fn judgment_answers_accept_explanatory_notes() {
    let text = "1. A（蓝光散射更强）\n2. B（红光穿透更强）";
    let questions = [choice_question("1"), choice_question("2")];
    let answers = parse_answers(text, &questions).unwrap();
    assert_eq!(answers[0].content, "A");
    assert_eq!(answers[1].content, "B");
}
