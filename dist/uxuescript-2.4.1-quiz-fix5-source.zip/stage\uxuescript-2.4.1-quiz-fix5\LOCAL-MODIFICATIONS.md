# uXueScript 本地修改版验证

日期：2026-10-24。
源码基线：`unraous/uxuescript`，标签 `v2.4.1`，归档目录 `unraous-uxuescript-3127cc5`。

## 修改范围

- 在实际日志确认 `.ncells` 旧目录、缺失 `posCatalog_select` 后，增加旧学习页到新版入口的切换。
- 优先点击页面 `.experience` 入口；否则仅对两个已知 `studentstudy` 路径调整新版地址，保留其他查询参数、重复参数和片段。
- 新版目录已存在、当前地址已是目标地址、其他页面路径时不改写。
- 目录为空、无法识别或章节数量减少时立即停止，禁止发送课程完成状态。
- 每轮处理后等待 5 秒再扫描目录；完成数增加、章节解锁或新增章节时重置计数，连续三轮无进展才停止，给目录同步留出时间。
- 明确的任务、页签或章节异常保留到本轮结束后停止，不再按目录同步原因重复请求同一失败测验；本轮其他任务仍继续处理。
- 首个视频或章节完成后继续处理后续未完成任务；正常模式只有全部已识别章节完成时才报告完成和 100% 进度。
- 调试模式保持只扫描一轮；仍有未完成章节时不报告课程完成。
- 课程入口识别新增 `mooc1-数字.chaoxing.com` 域名和 `/mooc-ans/mycourse/` 路径。
- 保留旧 `mooc1.chaoxing.com/mycourse/`；其他页面不会误判为课程，不扩大现有 WebView 权限。
- 新增共用答案解析器，并接入 Chat Completions、Responses、Gemini 三种接口。
- 支持原 JSON 数组、完整 JSON 代码块、`answers` 数组包装和单个答案对象。
- 单道无选项简答题允许返回纯文本，并保留原文和题号。
- 单选、多选、判断题支持带原题号的编号答案列表和两列 Markdown 答案表格，兼容实际日志中的加粗、对错标注及一致完整摘要。
- 编号分隔符兼容全角句点、顿号、右括号与冒号，同一行内的多个答案可拆分；答案与解析段标题兼容加粗、`#` 前缀及“解析/说明/分析”写法；答案之间的 Markdown 分隔线会被忽略。
- 无法识别的答案行会在错误信息中附带该行原文，便于定位下一种未兼容格式。
- 模型把 JSON 字符串结尾的英文引号写成中文引号、导致整段无法解析时，按行补齐未闭合的引号后重试；只有补齐后仍能解析成合法 JSON 才会采用。
- 每个答案区块均须完整；缺题、重复题号、未知题号、非法选项、冲突摘要及矛盾的判断注释仍然拒绝。
- JSON 与编号答案均恢复原题顺序，避免前端按数组位置填答时串题。
- 拒绝答案数量不符、题号未知或重复、空答案、损坏 JSON 及错误对象。

源码变更文件：

```text
LESSONS.md
src-tauri/src/core/quiz/llm.rs
src-tauri/src/core/quiz/llm/dispatcher.rs
src-tauri/src/core/quiz/llm/parse.rs
src-tauri/tests/unit/core/quiz/llm/dispatcher.rs
src-tauri/tests/unit/core/quiz/llm/parse.rs
src-tauri/tests/unit/commands/chaoxing.rs
src-tauri/src/core/url.rs
src-tauri/tests/unit/core/url.rs
src-tauri/src/scripts/core.js
tests/scripts/core-course.test.ts
tests/scripts/core-debug.test.ts
tests/support/core.ts
docs/troubleshooting.md
```

## 回归样本

截图中的 `mooc1-2.chaoxing.com/mooc-ans/mycourse/` 旧版分类为 `Other`，
页面可以打开，但不会注入课程脚本，因此仪表盘一直显示“待加载”。
本次覆盖新旧域名与路径组合、非数字后缀和外部域名拒绝，以及实际脚本选择。

随后实际日志反复出现“获取课程列表失败”，5 秒后误报“课程已完成”。
增加的本地结构诊断确认：页面加载完成，旧目录 `.ncells` 有 17 个，
新版 `posCatalog_select` 节点为 0；目录不在其他 iframe 中。
因此本版保留完成条件修复，并补充已知旧学习页向新版入口切换。
这不是对旧目录任务点击、锁定与完成标记的完整适配。

随后实际运行日志确认旧目录已切换成功，新版目录包含 22 个节点，其中 5 个标题、
17 个实际章节；脚本已进入练习题，随后进入下一章的视频任务。
练习题任务点的 DOM 已标为完成，但 5 秒后顶层章节目录仍显示未完成，
触发了此前的一轮无进展停止条件。本次针对这个实际现象增加连续三轮重试，
没有加入整页强制刷新，也没有仅凭任务处理动作就认定课程完成。

本次用户报告“死循环”后检查实际日志：19:19 至 19:24 的运行反复进入“练习题3”，
模型对题号 36 至 40 返回普通编号列表、加粗文字或表格，
因不符合 JSON 被拒绝。内层错误被记录并吞下，外层把它当成目录等待同步，
导致一次启动中重复请求三次，停止后再次启动仍然重现。
本版既兼容这些明确编号的答案格式，也保留内层处理错误，在本轮结束后停止自动重试。
原模型系统提示已包含 JSON 要求，本次没有新增未经验证的接口参数。

19:52 的新运行已验证解析错误后不会自动重复求解同一测验；
随后暴露出“简要说明：”解释标题尚未识别的问题。
现已补充该标题，并把用户提供的完整返回文本加入独立回归测试，
同时验证解释段不能补齐缺失答案或覆盖已识别答案。

用户报告的原始文本已加入解析测试、三协议本地 HTTP 回归测试，以及连接测试命令的完整调用测试：

```text
因为太阳光进入大气层后，波长较短的蓝光被空气分子散射得比波长较长的光更强烈，所以天空呈蓝色
```

## 验证记录

- 2026-10-24 21:40 修订：`cargo test --workspace --locked` 通过 97 项、0 项失败、13 项按原设置跳过；新增“JSON 字符串以中文引号收尾时补引号后重试”回归，样本取自 21:35 的实际返回文本。
- 2026-10-24 20:35 修订：`cargo test --workspace --locked` 通过 96 项、0 项失败、13 项按原设置跳过；新增“全角分隔符与单行多答案”“单行摘要多答案”“忽略答案间分隔线”三项解析回归，既有 45 项解析测试全部保留并通过。
- 同一修订的 `pnpm test --maxWorkers=1`：21 个文件中 19 个通过，161 项用例通过、4 项跳过；`tests/tooling/sync-config.test.ts` 因临时目录 `EIO, Access is denied` 失败，`tests/updater/server.test.ts` 的完整样本用例 30 秒超时。两项与本次 Rust 解析改动无关，未修改相关代码。
- `pnpm tauri build --no-bundle --ci -- --locked`：Windows x64 发行版构建成功（release 编译 2 分 36 秒）。
- 更早一轮的完整验证记录如下。
- `pnpm test --maxWorkers=1`：21 个文件、166 项前端与脚本测试全部通过。
- 首次并行测试有一个更新器测试工作进程异常退出；全部用例按单进程重跑通过，没有删除或跳过该文件。
- `pnpm build`：类型检查及前端生产构建通过。
- `cargo test --workspace --locked`：110 项通过、0 项失败；13 项需要外部服务的测试按原设置跳过。
- 覆盖首视频完成后仍处理下一视频、目录缺失或延迟、未知节点、连续三轮无进展停止、进展计数重置、解锁、目录数量减少、调试结束状态及 11 项旧目录切换场景。
- 新增第 11 秒才同步完成并解锁下一章的模拟场景，以及两轮无进展后取得进展、再等待两轮后完成的场景。
- 新增实际内层 Quiz 异常被捕获后，后续 PDF 和章节仍处理、Quiz 仅调用一次、主流程取消且保留错误原因的回归；目录同时已完成也不误发完成。
- 真实返回格式回归覆盖编号列表、加粗、两列表格、完整摘要、独立解析段；另覆盖逆序恢复、缺题、重复、未知题号、冲突摘要及非法选项。
- 三种接口的本地 HTTP 测试均验证编号判断答案，并核对请求确实包含原系统提示。
- 用户最新的“答案 + 36 至 40 编号列表 + 简要说明”完整原文通过解析回归；同类格式通过三协议本地 HTTP 测试。
- 之前的 JSON 和网址识别回归测试全部保留并通过。
- 修改的 Rust 文件按 `rustfmt` 格式化，新增入口文件的 `rustfmt --check` 通过。
- `pnpm tauri build --no-bundle --ci -- --locked`：Windows x64 发行版构建成功。
- 旧目录切换版的实际运行已确认切换成功、读取新版目录并进入后续章节。
- 已启动输出目录的 `quiz-fix` EXE；进程正常响应，窗口句柄有效。
- 本次正常关闭一个旧版进程后启动修复版，无需强制关闭；启动前后已保存配置的 SHA-256 相同。

上述自动化 HTTP 测试使用模拟服务，不读取用户密钥，也不会消耗真实模型额度。
实际服务连接仍以客户端测试结果为准。
旧页面结构、切换成功与进入后续章节的结论来自本机实际日志；
连续三轮重试、延迟更新、计数重置及任务出错停止重试的测试使用本地模拟 DOM。
本次模型格式兼容使用实际返回文本作为本地样本，未通过测试脚本请求真实模型。
尚未验证本次修改在实际课程中持续执行至整门课程完成。

## 2026-10-25 后期测试修订（quiz-fix5）

外部后期测试（匿名拉取、离线仿真与二进制检查）复现出四类“模型换个排版就整题失败”的边界。本版只放宽解析容忍度，不放宽任何校验：

- 纯文本答案里的引用编号（如 `[3]`）不再被当成 JSON：`has_json_syntax` 改为只认整段以 `{` / `[` / `"` 开头、含代码围栏，或出现 `{"` / `[{`。
- 简答题回答允许以“解析:”“说明:”等中文标签开头：`looks_like_json` 只把“英文字段名 + 带引号值”当 JSON 残片。
- 支持“题号 / 答案 / 解析”三列 Markdown 表格，第三列按说明忽略（`table_cells` 只取前两列）。
- 判断题的括号说明（如 `1. A（蓝光散射更强）`）按解释接受；仍拒绝 `A（应选B）` 这类指向其他选项的注释（`disagrees_with_choice`）。

保持不变：真正的 JSON 残片、`index: "1"` 这类无花括号片段、答案数量不符、题号未知或重复、空答案、非法选项、标注冲突仍全部拒绝。原 `rejects_malformed_tables_and_missing_table_separators` 中“三列表格必须失败”一条改为 `accepts_three_column_tables_with_an_explanation_column`，属于行为变更而非放宽校验。

验证：

- `cargo test --workspace --locked`：`uxs_commands` 17 项、`uxuescript` 101 项通过，0 失败，13 项按原设置跳过（fix4 时为 97 项，本次新增 4 项回归）。
- `vitest run tests/scripts`：7 个文件、71 项通过。
- `rustfmt --edition 2024 --check`：`parse.rs` 与其单元测试文件无差异。
- `tauri build --bundles nsis --config <关闭 createUpdaterArtifacts> --ci -- --locked`：release 编译 3 分 12 秒，安装包与绿色版为同一次构建。

本次未登录真实课程，也未请求真实模型服务；课程侧行为仍以实际使用为准。

## 修改版文件

Windows 安装包：`uXueScript_2.4.1_quiz-fix5_x64-setup.exe`。
大小：6,190,634 字节。
由同一份修改源码以 `--bundles nsis` 构建；构建时通过 `--config` 关闭 `createUpdaterArtifacts`，因为本机没有配置 Tauri updater 签名私钥。安装包与绿色版共用同一配置目录，安装不会清除已有配置。

SHA-256：

```text
1a79b6e633a7d6c0b44475dceff3d3d08a1fa37048b643e8299b2a96183b29c1
```

绿色版：`uxs-2.4.1-quiz-fix5-win-x64.exe`。
大小：12,990,464 字节。
SHA-256：

```text
f66d6996eef4fcee57a8d95c1584dffdba1e64630daa8d07273d864ba63939f4
```

源码包：`uxuescript-2.4.1-quiz-fix5-source.zip`，4,526,933 字节（不含本文件写入前后产生的哈希，包文件哈希见仓库根 `SHA256SUMS.txt`）。

此前版本 `uxs-2.4.1-quiz-fix4-win-x64.exe` 大小为 12,989,440 字节，SHA-256：

```text
704a174f1ec56b66b2682c7f8311069bd68c0024565ad640ae1b8227a37897d5
```

此前版本 `uxs-2.4.1-quiz-fix3-win-x64.exe` 大小为 12,988,416 字节，SHA-256：

```text
c30a250ad91104f47f0d6c7f2597f58e54d4390a676bcaf1596ee244788ea3b2
```

此前版本 `uxs-2.4.1-quiz-fix-win-x64.exe` 大小为 12,983,296 字节，SHA-256：

```text
80f6d80c548afe5474a5c3811e145b16c033c550aad650c395523d8d3c0ce989
```

输出 EXE 与本机构建产物的哈希一致。
应用内版本号保留上游 `2.4.1`，修改版通过文件名 `quiz-fix5` 区分。
官方原版和之前的修改版 EXE 在同目录保留。

## 构建环境

Node.js 24.21.0、pnpm 12.3.4、Rust 1.98.1、Windows x64 MSVC。
保留上游的 `x86-64-v3` 处理器目标，使用 Rust 自带的 MSVC LLD 链接器。
完整源码压缩包包含依赖锁文件和原始许可证，不包含依赖缓存、构建产物或用户配置。

在已安装上述版本 Node.js、pnpm、Rust 和 Microsoft C++ 构建工具的环境中，
解压源码后可在源码根目录用 PowerShell 复现：

```powershell
$rustSysroot = rustc --print sysroot
$env:CARGO_TARGET_X86_64_PC_WINDOWS_MSVC_LINKER = Join-Path $rustSysroot 'lib\rustlib\x86_64-pc-windows-msvc\bin\rust-lld.exe'
pnpm install --frozen-lockfile
pnpm test --maxWorkers=1
pnpm build
cargo test --workspace --locked
pnpm tauri build --no-bundle --ci -- --locked
```

本地修改日期及文件清单见本文开头。上游根许可证、第三方声明和字体许可证均原样保留在源码包中。
